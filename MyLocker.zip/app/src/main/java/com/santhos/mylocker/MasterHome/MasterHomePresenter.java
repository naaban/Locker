package com.santhos.mylocker.MasterHome;

public interface MasterHomePresenter {

    void getStatus();
    void getOpen(Integer otp);
    void getClose(Integer otp);
}

