package com.santhos.mylocker;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;

import com.google.android.material.button.MaterialButton;
import com.mukesh.OnOtpCompletionListener;
import com.mukesh.OtpView;
import com.robinhood.ticker.TickerUtils;
import com.robinhood.ticker.TickerView;
import com.santhos.mylocker.Login.LoginActivity;
import com.santhos.mylocker.MasterHome.MasterHomeActivity;
import com.santhos.mylocker.MasterLogin.MasterLogin;
import com.santhos.mylocker.MyConst.MyConst;
import com.santhos.mylocker.customComponent.RollingTextView;

import java.io.IOException;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import it.ennova.zerxconf.ZeRXconf;
import it.ennova.zerxconf.model.NetworkServiceDiscoveryInfo;
import rx.Subscriber;
import rx.Subscription;

public class MainActivity extends AppCompatActivity implements  MainActivityView {



    public AlertDialog  alertDialog;
    private Integer accessKey = 0;
    Handler handler;
    Runnable runnable;

    @BindView(R.id.status)
    public AppCompatTextView status;

    @BindView(R.id.ver_otp)
    public MaterialButton verOtp;

    @BindView(R.id.etOtp)
    RollingTextView etOtp;

    @BindView(R.id.masterLogin)
    public LinearLayout masterLogin;

    int clickCount = 0;
    private boolean notConnected = false;
    MainActivityViewModel mainActivityViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        status.setText(MyConst.CONNECTED);
        alertDialog = MyConst.getLoadingDialog(this);
        mainActivityViewModel =  new MainActivityViewModel(this);
        verOtp.setVisibility(View.GONE);
        mainActivityViewModel.getKey();


    }

    @Override
    public void showSpinner() {
        alertDialog.show();
    }

    @Override
    public void hideSpinner() {
       alertDialog.hide();
    }


    @Override
    public void OnFailed(String message) {

        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        status.setText(MyConst.NOT_CONNECTED);
    }

    @Override
    public void OnNetworkError(Throwable err) {
        if(err instanceof IOException)  {
            Toast.makeText(this, err.toString(), Toast.LENGTH_SHORT).show();
            status.setText(MyConst.NOT_CONNECTED);

        }
        else {

        }
    }


    @Override
    public void OnStatusSuccess() {
        status.setText(MyConst.CONNECTED);
//        status.setTextColor(getResources().getColor(R.color.green));
    }

    @Override
    public void OnKeyReceived(Integer key) {
        etOtp.setNumber(String.valueOf(key));
        verOtp.setVisibility(View.VISIBLE);

    }

    @Override
    public void OnOtpSuccess() {
        Intent intent = new Intent(MainActivity.this , MasterHomeActivity.class);
        intent.putExtra(MyConst.ACCESS_CODE , accessKey);
        startActivity(intent);
    }


    @OnClick(R.id.ver_otp)
    public void masterLogin(){

    }

    @OnClick(R.id.masterLogin)
    public void masterLgin(){
        clickCount ++;
        if(clickCount == 3) {
            startActivity(new Intent(MainActivity.this , MasterLogin.class));
            clickCount = 0;
        }
    }
}
