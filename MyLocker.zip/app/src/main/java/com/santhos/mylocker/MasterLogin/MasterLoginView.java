package com.santhos.mylocker.MasterLogin;

public interface MasterLoginView {
    void showSpinner();
    void hideSpinner();
    void OnLoginSuccess();
    void OnFailed(String message);
    void OnNetworkError(Throwable err);
}
