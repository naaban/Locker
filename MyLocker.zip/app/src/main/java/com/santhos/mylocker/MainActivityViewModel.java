package com.santhos.mylocker;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.santhos.mylocker.ApiService.Api;
import com.santhos.mylocker.ApiService.ApiClient;
import com.santhos.mylocker.Models.Response;
import com.santhos.mylocker.MyConst.MyConst;

import io.reactivex.Observer;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class MainActivityViewModel implements  MainActivityPresenter {

    private MainActivityView mainActivityView ;
    public MainActivityViewModel(MainActivityView mainActivityView) {
     this.mainActivityView = mainActivityView;
    }


    @Override
    public void getStatus() {
//        mainActivityView.showSpinner();
        Api.getInstance(MyConst.getIpAddress((Context) mainActivityView, MyConst.IP_ADDRESS)).create(ApiClient.class).getStatus().observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Observer<Response>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(Response response) {
//                mainActivityView.hideSpinner();
                if( response.getResponse().equals("ok")) {
                    mainActivityView.OnStatusSuccess();
                }
                else  mainActivityView.OnFailed("Failed to get response");
            }

            @Override
            public void onError(Throwable e) {
//                mainActivityView.hideSpinner();
                mainActivityView.OnNetworkError(e);
            }

            @Override
            public void onComplete() {

            }
        });

    }

    @Override
    public void getKey() {
        mainActivityView.showSpinner();
        Api.getInstance(MyConst.getIpAddress((Context) mainActivityView, MyConst.IP_ADDRESS)).create(ApiClient.class).getOtp().observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Observer<Response>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(Response response) {
                mainActivityView.hideSpinner();
                if( response.getResponse().equals("ok")) {
                    mainActivityView.OnKeyReceived(Integer.parseInt(response.getKey()));
                }
                else  mainActivityView.OnFailed("Failed to get response");
            }

            @Override
            public void onError(Throwable e) {
                mainActivityView.hideSpinner();
                mainActivityView.OnNetworkError(e);
            }

            @Override
            public void onComplete() {

            }
        });

    }

    @Override
    public void optAccess(Integer otp) {
        mainActivityView.showSpinner();
        Api.getInstance(MyConst.getIpAddress((Context) mainActivityView, MyConst.IP_ADDRESS)).create(ApiClient.class).getVerifyOtp(otp).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Observer<Response>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(Response response) {
                mainActivityView.hideSpinner();
                if( response.getResponse().equals("ok")) {
                    mainActivityView.OnOtpSuccess();
                }
                else  mainActivityView.OnFailed("Failed to get response");
            }

            @Override
            public void onError(Throwable e) {
                mainActivityView.hideSpinner();
                mainActivityView.OnNetworkError(e);
            }

            @Override
            public void onComplete() {

            }
        });
    }
}
