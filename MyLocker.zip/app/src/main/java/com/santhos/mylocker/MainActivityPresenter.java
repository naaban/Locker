package com.santhos.mylocker;

public interface MainActivityPresenter {
    void getStatus();
    void getKey();
    void optAccess(Integer otp);
}
