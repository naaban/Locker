package com.santhos.mylocker.Login;

public interface LoginPresenter {

    void getLogin(String username , String password);
}
