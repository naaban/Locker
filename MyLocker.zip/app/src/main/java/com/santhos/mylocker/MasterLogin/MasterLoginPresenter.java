package com.santhos.mylocker.MasterLogin;

public interface MasterLoginPresenter {

    void getLogin(String username , String password);
}
